#Metodos auxiliares que tienen que definirse antes de llamarlos
function ComprobarSiExiste(){
	#comprobar que el anio existe en Fconfiguracion
	anio=$1
	backIFS=$IFS
	var1=0
	while IFS='' read -r line || [[ -n "$line" ]];
	do 
		anioAux=`echo $line | cut -d: -f1`
		if  ([ $anio = $anioAux ])
		then 
			var1=1
		fi

	done <Fconfiguracion
	return $var1
}

function comprobarAnio(){
	#comprobar que el anio existe en Fconfiguracion
	anio=$1
	backIFS=$IFS
	var1=0
	while IFS='' read -r line || [[ -n "$line" ]];
	do 
		anioAux=`echo $line | cut -d: -f1`
		if  ([ $anio = $anioAux ])
		then 
			var1=1
		fi

	done <Fconfiguracion
	return $var1
}
#----------------------------------METODOS DE COFIGURACION---------------------------------------------------------------------------

function configuracionMenu(){
	var=1
	while(($var !=4))
	do
		clear
		printf "%s\n" "-------------------------Menu Configuración-----------------------------"
		printf "%s\n" "		1. Alta"
		printf "%s\n" "		2. Modificación"
		printf "%s\n" "		3. Baja"
		printf "%s\n" "		4. Salir"
		printf "%s\n" "------------------------------------------------------------------------"
		read var
		case $var in 
			1)	altaConfig
var=1;;
2)	modificaionConfig
var=1;;
3)	bajaConfig
var=1;;
4)	;;
*)	;;

esac
done
}

function altaConfig(){
	clear
	printf "%s\n" "Bienvenido a alta del curso academico"
	printf "%s\n" "------------------------------------------------------------------------"
	printf "%s\n" ""
	printf "%s\n" ""
	printf "%s\n" "Introduzca el nombre y los dos apellidos del profesor de practicas de 1º"
	printf "%s\n" "Ej:Mario Lopez Vazquez"
	read prof1
	while [ -z "$prof1" ]
	do
		printf "%s\n" "No has introducido un nombre,vuelve a intentarlo"
		read prof1
	done 

	printf "%s\n" "Introduzca el nombre y los dos apellidos del profesor de practicas de 2º"
	read prof2
	while [ -z "$prof2" ]
	do
		printf "%s\n" "No has introducido un nombre,vuelve a intentarlo"
		read prof2
	done 

	printf "%s\n" "Introduzca el nombre y los dos apellidos del profesor de practicas de 3º"
	read prof3
	while [ -z "$prof3" ]
	do
		printf "%s\n" "No has introducido un nombre,vuelve a intentarlo"
		read prof3
	done 

	printf "%s\n" "Introduzca el numero de practicas a realizar (minimo 1 ,maximo 3)"
	read pract
	while (($pract>3 || $pract<1))
	do
		printf "%s\n" "Introduzca un numero de practicas correcto (minimo 1 ,maximo 3)"
		read pract
	done 

	
		#if[-z "$var1" -a "$var1" -le 0 -a "$var1" -gt 100 ]
		
		printf "%s\n" "Introduzca el porcentaje de evaluacion de cada una de las practicas entre 0 y 100(sin el %)"
		case $pract in
			1)
printf "%s\n" "Introduzca el porcentaje de la practica 1:"
read var1
while ([ -z "$var1" ]) ||  ([ $var1 -ne 100 ])
do
	printf "%s\n" "No has introducido porcentaje valido, vuelve a intentarlo"
	read var1
done 
porcentaje="$var1:0:0"
;;
2)
sum=0
while ([ $sum -ne 100 ]) 

do
	printf "%s\n" "Nota: los 2 porcetajes deben sumar 100"
	printf "%s\n" "Introduzca el porcentaje de la practica 1:"
	read var1
	while [ -z "$var1" ]
	do
		printf "%s\n" "No has introducido porcentaje valido, vuelve a intentarlo"
		read var1
	done 
	printf "%s\n" "Introduzca el porcentaje de la practica 2:"
	read var2
	while [ -z "$var2" ]
	do
		printf "%s\n" "No has introducido porcentaje valido, vuelve a intentarlo"
		read var2
	done 
	sum=$(($var1+$var2))
	echo $sum
done
porcentaje="$var1:$var2:0"
;;
3)
sum=0
while ([ $sum -ne 100 ]) 

do
	printf "%s\n" "Nota: los 2 porcetajes deben sumar 100"
	printf "%s\n" "Introduzca el porcentaje de la practica 1:"
	read var1
	while [ -z "$var1" ]
	do
		printf "%s\n" "No has introducido porcentaje valido, vuelve a intentarlo"
		read var1
	done 
	printf "%s\n" "Introduzca el porcentaje de la practica 2:"
	read var2
	while [ -z "$var2" ]
	do
		printf "%s\n" "No has introducido porcentaje valido, vuelve a intentarlo"
		read var3
	done 
	printf "%s\n" "Introduzca el porcentaje de la practica 3:"
	read var3
	while [ -z "$var3" ]
	do
		printf "%s\n" "No has introducido porcentaje valido, vuelve a intentarlo"
		read var3
	done 
	sum=$(($var1+$var2+$var3))
	echo $sum
done

porcentaje="$var1:$var2:$var3"

;;
esac


printf "%s\n" "Introduzca anio del curso"
read anio
ComprobarSiExiste $anio
return=$?
while   ([ -z "$anio" ]) ||([ 1 -eq "$return" ])
do
	printf "%s\n" "Ese curso ya esta especificado, o vacio, introduzca otro año"
	read anio
	ComprobarSiExiste $anio
	return=$?

done 

periodo="$anio-$(($anio+1))"
Linea="$anio:$periodo:SO:$prof1:$prof2:$prof3:$pract:$porcentaje"
printf "%s\n" "Se ha introducido la siguiente linea en el fichero Fconfiguracion:"
echo $Linea
echo $Linea>>Fconfiguracion
printf "%s\n" "Pulsa enter para continuar"
read para
}




function modificaionConfig(){
	clear
	printf "%s\n" "---------------------------------------------------------------------------------------------"
	printf "%s\n" "NumLinea profesor 1	 	profesor 2	 	profesor 3	NumPracticas Porcentaje"
	printf "%s\n" "---------------------------------------------------------------------------------------------"
	cont=1;
	backIFS=$IFS
	while IFS='' read -r line || [[ -n "$line" ]];
	do 
		var2=`echo $line | cut -d: -f4`
		var3=`echo $line | cut -d: -f5`
		var4=`echo $line | cut -d: -f6`
		var5=`echo $line | cut -d: -f7`
		var6=`echo $line | cut -d: -f8`
		var7=`echo $line | cut -d: -f9`


		echo  $cont"	"$var2"		"$var3"		"$var4"	"$var5"-"$var6"-"$var7


		cont=$(($cont+1))

	done <Fconfiguracion
	num=$(cat Fconfiguracion | wc -l)
	echo -n "Introduce una linea para seleccionar: "
	read numlinea
	while ([ $numlinea -le 0 ])||  ([ $numlinea -gt $num ])
	do
		echo -n "Introduce una linea valida: "
		read numlinea
	done



	printf "%s\n" ""
	printf "%s\n" ""
	echo "Tu linea es:"
	printf "%s\n" "profesor 1	 	profesor 2	 	profesor 3	NumPracticas Porcentaje"
	awk -F ":" 'NR =='$numlinea' {print $4"		"$5"		"$6"			"$7"	"$8"-"$9"-"$10}'	Fconfiguracion
	var=1
	LineaActual=`awk "NR == $numlinea" Fconfiguracion`
	while(($var !=8))
	do
		printf "%s\n" "-------------------------Introduce el parametro a modificar-----------------------------"
		printf "%s\n" "		1. Nombre profesor 1º"
		printf "%s\n" "		2. Nombre profesor 2º"
		printf "%s\n" "		3. Nombre profesor 3º"
		printf "%s\n" "		4. Numero de practicas"
		printf "%s\n" "		5. Porcentaje de las practicas 1"
		printf "%s\n" "		6. Porcentaje de las practicas 2"
		printf "%s\n" "		7. Porcentaje de las practicas 3"
		printf "%s\n" "		8. Salir"
		printf "%s\n" "------------------------------------------------------------------------"
		read var
		case $var in 
			1)	
echo "Introduce el nuevo nombre del profesor 1 con sus dos apelliddos"
read nombre1Cambio

while [ -z "$nombre1Cambio" ]
do
	printf "%s\n" "No has introducido nombre valido"
	read nombre1Cambio
done
grep -v "$LineaActual" Fconfiguracion > Faux
LineaNueva=`echo $LineaActual | cut -d: -f1-3`
LineaNuevaAux=`echo $LineaActual | cut -d: -f5-10`
LineaAux=$LineaNueva:$nombre1Cambio:$LineaNuevaAux
echo $LineaAux >> Faux
mv Faux Fconfiguracion
echo "La nueva linea sera:"
echo $LineaAux
var=1;;
2)	
echo "Introduce el nuevo nombre del profesor 2 con sus dos apelliddos"
read nombre1Cambio
while [ -z "$nombre1Cambio" ]
do
	printf "%s\n" "No has introducido nombre valido"
	read nombre1Cambio
done
grep -v "$LineaActual" Fconfiguracion > Faux
LineaNueva=`echo $LineaActual | cut -d: -f1-4`
LineaNuevaAux=`echo $LineaActual | cut -d: -f6-10`
LineaAux=$LineaNueva:$nombre1Cambio:$LineaNuevaAux
echo $LineaAux >> Faux
mv Faux Fconfiguracion
echo "La nueva linea sera:"
echo $LineaAux
var=1;;
3)	
echo "Introduce el nuevo nombre del profesor 3 con sus dos apelliddos"
read nombre1Cambio
while [ -z "$nombre1Cambio" ]
do
	printf "%s\n" "No has introducido nombre valido"
	read nombre1Cambio
done
grep -v "$LineaActual" Fconfiguracion > Faux
LineaNueva=`echo $LineaActual | cut -d: -f1-5`
LineaNuevaAux=`echo $LineaActual | cut -d: -f7-10`
LineaAux=$LineaNueva:$nombre1Cambio:$LineaNuevaAux
echo $LineaAux >> Faux
mv Faux Fconfiguracion
echo "La nueva linea sera:"
echo $LineaAux
var=1;;
4)	
echo "Introduce el nuevo numero de practicas min 1 max 3"
read nombre1Cambio
while [[ -z $nombre1Cambio ]]||[[ $nombre1Cambio < 1 ]]||[[ $nombre1Cambio > 3 ]]
do
	printf "%s\n" "No has introducido valor valido"
	read nombre1Cambio
done
grep -v "$LineaActual" Fconfiguracion > Faux
LineaNueva=`echo $LineaActual | cut -d: -f1-6`
LineaNuevaAux=`echo $LineaActual | cut -d: -f8-10`
LineaAux=$LineaNueva:$nombre1Cambio:$LineaNuevaAux
echo $LineaAux >> Faux
mv Faux Fconfiguracion
echo "La nueva linea sera:"
echo $LineaAux
var=1;;
5)	
echo "Introduce el nuevo porcentaje para la practica 1"
read nombre1Cambio
while [[ -z $nombre1Cambio ]]||[[ $nombre1Cambio < 0 ]]||[[ $nombre1Cambio > 100 ]]
do
	printf "%s\n" "No has introducido valor valido"
	read nombre1Cambio
done
grep -v "$LineaActual" Fconfiguracion > Faux
LineaNueva=`echo $LineaActual | cut -d: -f1-7`
LineaNuevaAux=`echo $LineaActual | cut -d: -f9-10`
LineaAux=$LineaNueva:$nombre1Cambio:$LineaNuevaAux
echo $LineaAux >> Faux
mv Faux Fconfiguracion
echo "La nueva linea sera:"
echo $LineaAux
var=1;;
6)	
echo "Introduce el nuevo porcentaje para la practica 2"
read nombre1Cambio
while [[ -z $nombre1Cambio ]]||[[ $nombre1Cambio < 0 ]]||[[ $nombre1Cambio > 100 ]]
do
	printf "%s\n" "No has introducido valor valido"
	read nombre1Cambio
done
grep -v "$LineaActual" Fconfiguracion > Faux
LineaNueva=`echo $LineaActual | cut -d: -f1-8`
LineaNuevaAux=`echo $LineaActual | cut -d: -f10`
LineaAux=$LineaNueva:$nombre1Cambio:$LineaNuevaAux
echo $LineaAux >> Faux
mv Faux Fconfiguracion
echo "La nueva linea sera:"
echo $LineaAux
var=1;;
7)	
echo "Introduce el nuevo porcentaje para la practica 3"
read nombre1Cambio
while [[ -z $nombre1Cambio ]]||[[ $nombre1Cambio < 0 ]]||[[ $nombre1Cambio > 100 ]]
do
	printf "%s\n" "No has introducido valor valido"
	read nombre1Cambio
done
grep -v "$LineaActual" Fconfiguracion > Faux
LineaNueva=`echo $LineaActual | cut -d: -f1-9`
LineaAux=$LineaNueva:$nombre1Cambio
echo $LineaAux >> Faux
mv Faux Fconfiguracion
echo "La nueva linea sera:"
echo $LineaAux
var=1;;	
8);;
*)	;;

esac
done

}

function bajaConfig(){
	clear
	printf "%s\n" "---------------------------------------------------------------------------------------------"
	printf "%s\n" "NumLinea profesor 1	 	profesor 2	 	profesor 3	NumPracticas Porcentaje"
	printf "%s\n" "---------------------------------------------------------------------------------------------"
	cont=1;
	backIFS=$IFS
	while IFS='' read -r line || [[ -n "$line" ]];
	do 
		var1=`echo $line | cut -d: -f4`
		var2=`echo $line | cut -d: -f5`
		var3=`echo $line | cut -d: -f6`
		var4=`echo $line | cut -d: -f7`
		var5=`echo $line | cut -d: -f8`
		var6=`echo $line | cut -d: -f9`
		var7=`echo $line | cut -d: -f10`


		echo  $cont"	"$var1"		"$var2"		"$var3"		"$var4"	"$var5"-"$var6"-"$var7


		cont=$(($cont+1))

	done <Fconfiguracion
	num=$(cat Fconfiguracion | wc -l)
	echo -n "Introduce una linea para seleccionar: "
	read numlinea
	while ([ $numlinea -le 0 ])||  ([ $numlinea -gt $num ])
	do
		echo -n "Introduce una linea valida: "
		read numlinea
	done

	printf "%s\n" ""
	printf "%s\n" ""
	echo "Tu linea es:"
	printf "%s\n" "profesor 1	 	profesor 2	 	profesor 3	NumPracticas Porcentaje"
	awk -F ":" 'NR =='$numlinea' {print $4"		"$5"		"$6"			"$7"	"$8"-"$9"-"$10}'	Fconfiguracion
	var=1
	LineaActual=`awk "NR == $numlinea" Fconfiguracion`
	grep -v "$LineaActual" Fconfiguracion > Faux
	mv Faux Fconfiguracion
	
}


#----------------------------------METODOS DE MATRICULACION---------------------------------------------------------------------------

function matriculacionMenu(){
	var=1
	while(($var !=6))
	do
		clear
		printf "%s\n" "-------------------------Menu Matriculación-----------------------------"
		printf "%s\n" "		1. Alta"
		printf "%s\n" "		2. Modificación"
		printf "%s\n" "		3. Baja estudiante"
		printf "%s\n" "		4. Control prácticas"
		printf "%s\n" "		5. Calcular nota"
		printf "%s\n" "		6. Salir"
		printf "%s\n" "------------------------------------------------------------------------"
		read var
		case $var in 
			1)	altaMatri
var=1;;
2)	modificaionMatri
var=1;;
3)	bajaMatri
var=1;;
4)	practicasMatri
var=1;;
5)	notaMatri
var=1;;
6)	;;	
*)	;;

esac
done

}

function altaMatri(){
	clear
	printf "%s\n" "Bienvenido a alta del estudiante"
	printf "%s\n" "------------------------------------------------------------------------"
	printf "%s\n" ""
	printf "%s\n" ""
	printf "%s\n" "Introduzca el nombre del estudiante"
	read n1
	while [ -z "$n1" ]
	do
		printf "%s\n" "No has introducido un nombre,vuelve a intentarlo"
		read n1
	done 
	printf "%s\n" "Introduzca el primer apellido del estudiante"
	read n2
	while [ -z "$n2" ]
	do
		printf "%s\n" "No has introducido un nombre,vuelve a intentarlo"
		read n2
	done 
	printf "%s\n" "Introduzca el segundo apellido del estudiante"
	read n3
	while [ -z "$n3" ]
	do
		printf "%s\n" "No has introducido un nombre,vuelve a intentarlo"
		read n3
	done 

	printf "%s\n" "Introduzca anio del curso"
	read anio
	comprobarAnio $anio
	return=$?
	while   ([ -z "$anio" ]) ||([ 0 -eq "$return" ])
	do
		printf "%s\n" "No existe ese anio en el sistema,o vacio, intentelo de nuevo"
		read anio
		comprobarAnio $anio
		return=$?

	done 


	if [ -s Fmatso ]
	then
		idest=`tail -n1 Fmatso| cut -d: -f2`
		idest=$(($idest+1))
	else
		idest=0
	fi
	Linea="$anio:$idest:$n1:$n2:$n3:S:-1"
	printf "%s\n" "Se ha introducido la siguiente linea en el fichero Fmatso:"
	echo $Linea
	echo $Linea>>Fmatso
#Para saber el numero de practicas de ese anio
numPracts=0
backIFS=$IFS
while IFS='' read -r line || [[ -n "$line" ]];
do 
	anioAux=`echo $line | cut -d: -f1`
	if  ([ $anio = $anioAux ])
	then 
		numPracts=`echo $line | cut -d: -f7`
	fi

done <Fconfiguracion


if  ([ $numPracts -eq 1 ])
then 
	LineaPract="$anio:$idest:1:N:-1"
	echo $LineaPract>>Fpracticas
fi
if  ([ $numPracts -eq 2 ])
then 
	LineaPract="$anio:$idest:1:N:-1"
	LineaPract2="$anio:$idest:2:N:-1"
	echo $LineaPract>>Fpracticas
	echo $LineaPract2>>Fpracticas
fi
if  ([ $numPracts -eq 3 ])
then 
	LineaPract="$anio:$idest:1:N:-1"
	LineaPract2="$anio:$idest:2:N:-1"
	LineaPract3="$anio:$idest:3:N:-1"
	echo $LineaPract>>Fpracticas
	echo $LineaPract2>>Fpracticas
	echo $LineaPract3>>Fpracticas

fi

printf "%s\n" "Pulsa enter para continuar"
read para


}


function modificaionMatri(){
	clear
	printf "%s\n" "-------------------------------------------------------------------------"
	printf "%s\n" "NumLinea idEstudiante Nombre  	apellido1	 	apellido2	"
	printf "%s\n" "-------------------------------------------------------------------------"
	cont=1;
	backIFS=$IFS
	while IFS='' read -r line || [[ -n "$line" ]];
	do 
		var1=`echo $line | cut -d: -f2`
		var2=`echo $line | cut -d: -f3`
		var3=`echo $line | cut -d: -f4`
		var4=`echo $line | cut -d: -f5`

		echo  $cont"	"$var1"		"$var2"		"$var3"		"$var4

		cont=$(($cont+1))

	done <Fmatso
	num=$(cat Fmatso | wc -l)
	echo -n "Introduce una linea para seleccionar: "
	read numlinea
	while ([ $numlinea -le 0 ])||  ([ $numlinea -gt $num ])
	do
		echo -n "Introduce una linea valida: "
		read numlinea
	done

	printf "%s\n" ""
	printf "%s\n" ""
	echo "Tu linea es:"
	printf "%s\n" "idEstudiante Nombre  	apellido1	 	apellido2	"
	awk -F ":" 'NR =='$numlinea' {print $2" "$3"		"$4"		"$5}'	Fmatso
	var=1
	LineaActual=`awk "NR == $numlinea" Fmatso`
	while(($var !=4))
	do
		printf "%s\n" "-------------------------Introduce el parametro a modificar-----------------------------"
		printf "%s\n" "		1. Nombre del estudiante "
		printf "%s\n" "		2. 1º Apellido del estudiante"
		printf "%s\n" "		3. 2º Apellido del estudiante"
		printf "%s\n" "		4. Salir"
		printf "%s\n" "------------------------------------------------------------------------"
		read var
		case $var in 
			1)	
echo "Introduce el nuevo nombre del estudiante"
read nombre1Cambio

while [ -z "$nombre1Cambio" ]
do
	printf "%s\n" "No has introducido nombre valido"
	read nombre1Cambio
done
grep -v "$LineaActual" Fmatso > Faux
LineaNueva=`echo $LineaActual | cut -d: -f1-2`
LineaNuevaAux=`echo $LineaActual | cut -d: -f4-7`
LineaAux=$LineaNueva:$nombre1Cambio:$LineaNuevaAux
echo $LineaAux >> Faux
mv Faux Fmatso
echo "La nueva linea sera:"
echo $LineaAux
var=1;;
2)	
echo "Introduce el nuevo 1º apellido del estudiante"
read nombre1Cambio
while [ -z "$nombre1Cambio" ]
do
	printf "%s\n" "No has introducido nombre valido"
	read nombre1Cambio
done
grep -v "$LineaActual" Fmatso > Faux
LineaNueva=`echo $LineaActual | cut -d: -f1-3`
LineaNuevaAux=`echo $LineaActual | cut -d: -f5-7`
LineaAux=$LineaNueva:$nombre1Cambio:$LineaNuevaAux
echo $LineaAux >> Faux
mv Faux Fmatso
echo "La nueva linea sera:"
echo $LineaAux
var=1;;
3)	
echo "Introduce el nuevo 2º apellido del estudiante"
read nombre1Cambio
while [ -z "$nombre1Cambio" ]
do
	printf "%s\n" "No has introducido nombre valido"
	read nombre1Cambio
done
grep -v "$LineaActual" Fmatso > Faux
LineaNueva=`echo $LineaActual | cut -d: -f1-4`
LineaNuevaAux=`echo $LineaActual | cut -d: -f6-7`
LineaAux=$LineaNueva:$nombre1Cambio:$LineaNuevaAux
echo $LineaAux >> Faux
mv Faux Fmatso
echo "La nueva linea sera:"
echo $LineaAux
var=1;;
4);;
*)	;;

esac
done

}

function bajaMatri(){
	clear
	#controlar no mostrar los estudiantes que ya se han puesto a N 
	printf "%s\n" "---------------------------------------------------------------------------------------------"
	printf "%s\n" "NumLinea idEstudiante Nombre  	apellido1	 	apellido2	NotaPractica"
	printf "%s\n" "---------------------------------------------------------------------------------------------"
	cont=1;
	backIFS=$IFS
	while IFS='' read -r line || [[ -n "$line" ]];
	do 
		var1=`echo $line | cut -d: -f2`
		var2=`echo $line | cut -d: -f3`
		var3=`echo $line | cut -d: -f4`
		var4=`echo $line | cut -d: -f5`
		activo=`echo $line | cut -d: -f6`
		var5=`echo $line | cut -d: -f7`
		if  ([ $activo = "S" ])
		then 
			echo  $cont"	"$var1"		"$var2"		"$var3"		"$var4"		"$var5
		fi

		cont=$(($cont+1))

	done <Fmatso
	num=$(cat Fmatso | wc -l)
	echo -n "Introduce una linea para seleccionar: "
	read numlinea
	while ([ $numlinea -le 0 ])||  ([ $numlinea -gt $num ])||([ $activo = "N" ])
	do
		echo -n "Introduce una linea valida: "
		read numlinea
	done

	printf "%s\n" ""
	printf "%s\n" ""
	echo "Tu linea es:"
	printf "%s\n" "idEstudiante Nombre  	apellido1	 	apellido2	NotaPractica"
	awk -F ":" 'NR =='$numlinea' {print $2" "$3"		"$4"		"$5"	"$7}'	Fmatso
	LineaActual=`awk "NR == $numlinea" Fmatso`
	idEst=`echo $LineaActual | cut -d: -f2`
	NotaPract=`echo $LineaActual | cut -d: -f7`


	backIFS=$IFS
	var1=0
	while IFS='' read -r line || [[ -n "$line" ]];
	do 
		idEstPract=`echo $line | cut -d: -f2`
		entregada=`echo $line | cut -d: -f4`

		if  ([ $idEst = $idEstPract ])&&([ $entregada = "S" ])
		then 
			var1=1	
		fi

	done <Fpracticas

	if([ 1 -eq $var1 ])
	then 
		echo "El estudiante tiene practicas por lo que se pondra su campo activo a N"
		grep -v "$LineaActual" Fmatso > Faux
		LineaNueva=`echo $LineaActual | cut -d: -f1-5`
		LineaAux=$LineaNueva:N:$NotaPract
		echo $LineaAux >> Faux
		mv Faux Fmatso
	else
		echo "Se elimino el estudiante"
		LineaActual=`awk "NR == $numlinea" Fmatso`
		grep -v "$LineaActual" Fmatso > Faux
		mv Faux Fmatso
	fi

	echo "Pulsa enter para continuar"
	read var1
}
function practicasMatri(){
	clear
	printf "%s\n" "---------------------------------------------------------------------------------------------"
	printf "%s\n" "NumLinea Curso Nombre  	apellido1	 	apellido2	NotaPractica"
	printf "%s\n" "---------------------------------------------------------------------------------------------"

	#Busqueda de estudiantes activos
	cont=1;
	backIFS=$IFS
	while IFS='' read -r line || [[ -n "$line" ]];
	do 
		curso=`echo $line | cut -d: -f1`
		nombre=`echo $line | cut -d: -f3`
		ap1=`echo $line | cut -d: -f4`
		ap2=`echo $line | cut -d: -f5`
		activo=`echo $line | cut -d: -f6`
		nota=`echo $line | cut -d: -f7`
		if  ([ $activo = "S" ]) && ([ $nota = -1 ])
		then 
			echo  $cont"       "$curso"    "$nombre"		"$ap1"		"$ap2"		Sin asignar"
		fi

		cont=$(($cont+1))

	done <Fmatso
	echo -n "Introduce la linea  para seleccionar al estudiante: "
	read numlinea
	num=$(cat Fmatso | wc -l)
	line=`awk "NR == $numlinea" Fmatso`
	activo=`echo $line | cut -d: -f6`
	while ([ $numlinea -le 0 ])||  ([ $numlinea -gt $num ])||([ $activo = "N" ])
	do
		echo -n "Introduce una linea valida: "
		read numlinea

	done
	printf "%s\n" ""
	printf "%s\n" ""
	echo "Tu linea es:"
	printf "%s\n" "Curso idEstudiante Nombre  	apellido1	 	apellido2	NotaPractica"
	awk -F ":" 'NR =='$numlinea' {print $1" 	 "$2" 	 "$3"		"$4"		"$5"	"$7}'	Fmatso
	
	LineaActual=`awk "NR == $numlinea" Fmatso`
	idEst=`echo $LineaActual | cut -d: -f2`
	

	cont=`cat Fpracticas | wc -l`
	for ((c=1; c<=cont; c++))
	do
		line=`awk "NR == $c" Fpracticas`
		idEstPract=`echo $line | cut -d: -f2`
		entregada=`echo $line | cut -d: -f4`

		if  ([ $idEst = $idEstPract ])&&([ $entregada = "N" ])
		then

			numPracts=`echo $line | cut -d: -f3`
			printf "%s\n" "Introduce una nota de la practica $numPracts"
			read notaAux

			while ([ -z "$notaAux" ]) || ([ "$notaAux" -lt 0 ]) || ([ "$notaAux" -gt 10 ])
			do
				printf "%s\n" "No has introducido una nota valida $numPracts"
				read notaAux
			done

			LineaNueva=`echo $line | cut -d: -f1-3`
			LineaAux=$LineaNueva:S:$notaAux

			`sed -i 's/'$line'/'$LineaAux'/g' Fpracticas`
		fi
	done

	echo "introduzca una tecla para continuar"
	read var5
}

function notaMatri(){
	clear
	printf "%s\n" "---------------------------------------------------------------------------------------------"
	printf "%s\n" "NumLinea Nombre  	apellido1	 	apellido2	NotaPractica"
	printf "%s\n" "---------------------------------------------------------------------------------------------"

	#Busqueda de estudiantes activos
	cont=1;
	backIFS=$IFS
	while IFS='' read -r line || [[ -n "$line" ]];
	do 
		nombre=`echo $line | cut -d: -f3`
		ap1=`echo $line | cut -d: -f4`
		ap2=`echo $line | cut -d: -f5`
		activo=`echo $line | cut -d: -f6`
		nota=`echo $line | cut -d: -f7`
		if  ([ $activo = "S" ]) && ([ $nota = -1 ])
		then 
			echo  $cont"	"$nombre"		"$ap1"		"$ap2"		Sin Asignar"
		fi

		cont=$(($cont+1))

	done <Fmatso
	echo -n "Introduce la linea  para seleccionar al estudiante: "
	read numlinea
	num=$(cat Fmatso | wc -l)
	line=`awk "NR == $numlinea" Fmatso`
	activo=`echo $line | cut -d: -f6`
	while ([ $numlinea -le 0 ])||  ([ $numlinea -gt $num ])||([ $activo = "N" ]) || ([ $nota != -1 ])
	do
		echo -n "Introduce una linea valida: "
		read numlinea

	done
	printf "%s\n" ""
	printf "%s\n" ""
	echo "Tu linea es:"
	printf "%s\n" "Curso idEstudiante Nombre  	apellido1	 	apellido2	NotaPractica"
	awk -F ":" 'NR =='$numlinea' {print $1"	  "$2"	 "$3"		"$4"		"$5"	Sin Asignar"}'	Fmatso
	
	LineaActual=`awk "NR == $numlinea" Fmatso`
	idEst=`echo $LineaActual | cut -d: -f2`
	anio=`echo $LineaActual | cut -d: -f1`	

	periodo="$anio-$(($anio+1))"
	lineaConfi=$( grep $periodo Fconfiguracion )
	por1=`echo $lineaConfi | cut -d: -f8`
	por2=`echo $lineaConfi | cut -d: -f9`
	por3=`echo $lineaConfi | cut -d: -f10`
	echo "Porcentaje de las practicas:"$por1","$por2","$por3


	cont=`cat Fpracticas | wc -l`
	media=0
	for ((c=1; c<=cont; c++))
	do
		line=`awk "NR == $c" Fpracticas`
		idEstPract=`echo $line | cut -d: -f2`
		entregada=`echo $line | cut -d: -f4`


		if  ([ $idEst = $idEstPract ])&&([ $entregada = "S" ])
		then
			nota=`echo $line | cut -d: -f5`
			numPractica=`echo $line | cut -d: -f3`
			case $numPractica in 
				1)	
aux1=$(echo "scale=2; $por1/100" |bc)
aux2=$(echo "scale=3; $aux1*$nota" |bc)
media=$(echo "scale=3; $media+$aux2" |bc)
echo "nota1 "$media
;;
2)	
aux1=$(echo "scale=2; $por2/100" |bc)
aux2=$(echo "scale=3; $aux1*$nota" |bc)
media=$(echo "scale=3; $media+$aux2" |bc)
echo "nota2 "$media

;;
3)	
aux1=$(echo "scale=2; $por3/100" |bc)
aux2=$(echo "scale=3; $aux1*$nota" |bc)
media=$(echo "scale=3; $media+$aux2" |bc)
echo "nota3 "$media
;;
*);;
esac



fi
done
if  ([ $cont = 0 ])
then
	echo "No tienes notas para hacer la media"		
else	
	echo "La media es "$media

	LineaNueva=`echo $LineaActual | cut -d: -f1-6`
	LineaAux=$LineaNueva:$media
	`sed -i 's/'$LineaActual'/'$LineaAux'/g' Fmatso`
fi


echo "introduzca una tecla para continuar"
read var5

}


#----------------------------------METODOS DE INFORMES---------------------------------------------------------------------------

function menuInforme(){
	var=1
	while(($var !=3))
	do
		clear
		printf "%s\n" "-------------------------Menu Informes-----------------------------"
		printf "%s\n" "		1. Consulta configuracion"
		printf "%s\n" "		2. Consulta estudiante"
		printf "%s\n" "		3. Salir"
		printf "%s\n" "------------------------------------------------------------------------"
		read var
		case $var in 
			1)	conConfi
var=1;;
2)	conEst
var=1;;
3)	;;	
*)	;;
esac
done
}

function conConfi(){
	clear
	echo "Elige una opcion"
	echo "1-Mostrar todos los cursos"
	echo "2-Mostrar cursos a eleccion"
	echo "3-Salir"
	read op
	if  ([ $op = 1 ])
	then
		
		printf "%s\n" "---------------------------------------------------------------------------------------------"
		printf "%s\n" "Curso profesor 1	 	profesor 2	 	profesor 3	NumPracticas Porcentaje"
		printf "%s\n" "---------------------------------------------------------------------------------------------"
		awk -F ":"  '{print $1"   "$4"		"$5"		"$6"			"$7"	"$8"-"$9"-"$10}'	Fconfiguracion |	sort -k 1 -t : 
	fi
	if  ([ $op = 2 ])
	then
		echo "Introduce el curso a buscar"
		read curs

		#se puede usar el grep pero no me funciona
		printf "%s\n" "---------------------------------------------------------------------------------------------"
		printf "%s\n" "Curso profesor 1	 	profesor 2	 	profesor 3	NumPracticas Porcentaje"
		printf "%s\n" "---------------------------------------------------------------------------------------------"

		backIFS=$IFS
		contV=0
		while IFS='' read -r line || [[ -n "$line" ]];
		do 
			curso=`echo $line | cut -d: -f1`
			prof1=`echo $line | cut -d: -f4`
			prof2=`echo $line | cut -d: -f5`
			prof3=`echo $line | cut -d: -f6`
			numPrac=`echo $line | cut -d: -f7`
			por=`echo $line | cut -d: -f8`
			por1=`echo $line | cut -d: -f9`
			por2=`echo $line | cut -d: -f10`

			if  ([ $curso = $curs ])
			then 
				
				if  ([ $numPrac = 1 ])
				then
					echo  $curso"	"$prof1"		"$prof2"		"$prof3"		"$numPrac"		"$por
					contV=$(($contV+1))
				fi

				if  ([ $numPrac = 2 ])
				then
					echo  $curso"	"$prof1"		"$prof2"		"$prof3"		"$numPrac"		"$por"-"$por1
					contV=$(($contV+1))
				fi

				if  ([ $numPrac = 3 ])
				then
					echo  $curso"	"$prof1"		"$prof2"		"$prof3"		"$numPrac"		"$por"-"$por1"-"$por2
					contV=$(($contV+1))
				fi
				

			fi


		done <Fconfiguracion

		if  ([ $contV = 0 ])
		then 
			clear
			echo "No existen datos para ese curso intentelo de nuevo"
		fi
	fi
	echo "pulsa enter para continuar"
	read enter
	
}

function conEst(){  
	clear
	echo "Elige una opcion"
	echo "1-Mostrar todos los estudiantes matriculados"
	echo "2-Mostrar los estudiantes matriculados en un cursos a eleccion"
	echo "3-Salir"
	read op


	if  ([ $op = 1 ])
	then		
		printf "%s\n" "---------------------------------------------------------------------------------------------"
		printf "%s\n" "NumLinea Curso idEstudiante Nombre y Apellidos 	NotaPracticas"
		printf "%s\n" "---------------------------------------------------------------------------------------------"
		backIFS=$IFS
		contV=0
		contLinea=1
		while IFS='' read -r line || [[ -n "$line" ]];
		do 
			var1=`echo $line | cut -d: -f1`
			var2=`echo $line | cut -d: -f2`
			var3=`echo $line | cut -d: -f3`
			var4=`echo $line | cut -d: -f4`
			var5=`echo $line | cut -d: -f5`
			var6=`echo $line | cut -d: -f7`

			if  ([ $var6 = -1 ])
			then 
				echo  $contLinea"	"$var1"		"$var2"		"$var3","$var4","$var5"		NP:4"
			else
				echo  $contLinea"	"$var1"		"$var2"		"$var3","$var4","$var5"		"$var6
			fi
			contV=$(($contV+1))
			contLinea=$(($contLinea+1))
			
		done <Fmatso	
		if  ([ $contV = 0 ])
		then 
			clear
			echo "No existen datos para ese curso intentelo de nuevo"
		else
			num=$(cat Fmatso | wc -l)
			echo -n "Introduce una linea para ver las practicas del estudiante: "
			read numlinea
			while ([ $numlinea -le 0 ])||  ([ $numlinea -gt $num ])
			do
				echo -n "Introduce una linea valida: "
				read numlinea
			done
			LineaActual=`awk "NR == $numlinea" Fmatso`
			idEst=`echo $LineaActual | cut -d: -f2`
			nombreEst=`echo $LineaActual | cut -d: -f3`


			printf "%s\n" "---------------------------------------------------------------------------------------------"
			printf "%s\n" "Curso idEstudiante Nombre 	NumPractica NotaPracticas"
			printf "%s\n" "---------------------------------------------------------------------------------------------"
			cont=`cat Fpracticas | wc -l`
			for ((c=1; c<=cont; c++))
			do
				line=`awk "NR == $c" Fpracticas`
				idEstPract=`echo $line | cut -d: -f2`
				if  ([ $idEst = $idEstPract ])
				then
					awk -F ":" 'NR =='$c' {print $1"  "$2" "$nombreEst"		"$3" "$5}'	Fpracticas
				fi	
			done
		fi
	fi	
	if  ([ $op = 2 ])
	then
		echo "Introduce el curso a buscar"
		read curs

		#se puede usar el grep pero no me funciona
		printf "%s\n" "---------------------------------------------------------------------------------------------"
		printf "%s\n" "NumLinea Curso idEstudiante Nombre y Apellidos 	NotaPracticas"
		printf "%s\n" "---------------------------------------------------------------------------------------------"

		backIFS=$IFS
		contV=0
		contLinea=1
		while IFS='' read -r line || [[ -n "$line" ]];
		do 
			var1=`echo $line | cut -d: -f1`
			var2=`echo $line | cut -d: -f2`
			var3=`echo $line | cut -d: -f3`
			var4=`echo $line | cut -d: -f4`
			var5=`echo $line | cut -d: -f5`
			var6=`echo $line | cut -d: -f7`

			if  ([ $var1 = $curs ])
			then 

				if  ([ $var6 = -1 ])
				then 
					echo  $contLinea"	"$var1"		"$var2"		"$var3","$var4","$var5"		NP:4"
				else
					echo  $contLinea"	"$var1"		"$var2"		"$var3","$var4","$var5"		"$var6
				fi
				contV=$(($contV+1))

			fi
			contLinea=$(($contLinea+1))


		done <Fmatso
		if  ([ $contV = 0 ])
		then 
			clear
			echo "No existen datos para ese curso intentelo de nuevo"

		else
			num=$(cat Fmatso | wc -l)

			echo -n "Introduce una linea para ver las practicas del estudiante: "
			read numlinea
			while ([ $numlinea -le 0 ])||  ([ $numlinea -gt $num ])
			do
				echo -n "Introduce una linea valida: "
				read numlinea
			done
			LineaActual=`awk "NR == $numlinea" Fmatso`
			idEst=`echo $LineaActual | cut -d: -f2`
			nombreEst=`echo $LineaActual | cut -d: -f3`


			printf "%s\n" "---------------------------------------------------------------------------------------------"
			printf "%s\n" "Curso idEstudiante Nombre 	NumPractica NotaPracticas"
			printf "%s\n" "---------------------------------------------------------------------------------------------"
			cont=`cat Fpracticas | wc -l`
			for ((c=1; c<=cont; c++))
			do
				line=`awk "NR == $c" Fpracticas`
				idEstPract=`echo $line | cut -d: -f2`
				if  ([ $idEst = $idEstPract ])
				then
					var1=`echo $line | cut -d: -f1`
					var2=`echo $line | cut -d: -f2`
					var3=`echo $line | cut -d: -f3`
					var4=`echo $line | cut -d: -f5`
					if  ([ $var6 = -1 ])
					then 
						echo  $var1"	"$var2"		"$nombreEst"		"$var3"  	No presentada"
					else
						echo  $var1"	"$var2"		"$nombreEst"		"$var3"  	"$var4

					fi

				fi
			done



		fi
	fi

	echo "pulsa enter para continuar"
	read enter
}
#----------------------------------Metodo de ayuda------------------------------------------------------------------------------

function ayuda(){  
	clear
	printf "%s\n" "---------------------------------------------------------------------------------------------"
	printf "%s\n"
	printf "%s\n"
	echo "Esta es una aplicacion cuyo fin es gestionar  la entrega de practicas de los "
	echo "estudiantes de la signatura de Sistemas Operativos para cualquier curso mediante "
	echo "archivos de texto."
	printf "%s\n"
	echo "La aplicacion dispone de varios menus y submenus con funcionalidades para poder "
	echo "desarrollar la labor para la cual esta diseñada."
	printf "%s\n"
	echo "Para moverse entre los submenus habra que pulsar numero entero para acceder a la"
	echo "opcion corespondiente."
	printf "%s\n"
	printf "%s\n"
	echo "Para mas informacion leer la documentacion de la practica 2.manual del usaurio"
	echo "o ponerse en contacto con el creador.  Usuario:mfolguer"
	printf "%s\n"
	printf "%s\n"
	printf "%s\n" "---------------------------------------------------------------------------------------------"
	echo "pulsa enter para continuar"
	read enter

}

#----------------------------------INICIO DEL PROGRAMA------------------------------------------------------------------------------
touch Fconfiguracion
touch Fpracticas
touch Fmatso
var=1
while(($var !=5))
do
	clear 
	printf "%s\n" "-------------------------Menu Principal-----------------------------"
	printf "%s\n" "			1. Configuración"
	printf "%s\n" "			2. Matrícula de estudiantes"
	printf "%s\n" "			3. Informes de seguimiento"
	printf "%s\n" "			4. Ayuda"
	printf "%s\n" "			5. Salir"
	printf "%s\n" "--------------------------------------------------------------------"
	read var
	case $var in 
		1)	configuracionMenu
var=1;;
2)	matriculacionMenu
var=1;;
3)	menuInforme
var=1;;
4)	ayuda
var=1;;
5)	;;
*);;

esac
done